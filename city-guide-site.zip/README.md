# Pre Production Plan

The aim of the website is to attract more tourists to Ennis and for the website to act as a booklet for the town.

User requirements include the need for a list of attractions, local businesses, a map of the area, some history of the town and a contact page.

# Interactive Features

Back to Top button at the bottom of the page which is used to scroll to the top of the page when clicked.

Navigation bar which has an active page indicator.

Buttons that link to outside resources which open in a new tab.

# An email link for enquires

The contact page has a button with a href using the mailto: protocol.

# Images

Images used are from Google. They are images of the town of Ennis as well as the attractions and local businesses mentioned in the content.

# Any animation

Hover animations on some images. Greyscale to colour animation and animated vignette.
